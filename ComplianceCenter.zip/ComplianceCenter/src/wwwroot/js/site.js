function updateValidationDisplay(formId) {
    var formIsValid = true;

    $('#' + formId).find('.form-control, .checkbox-validate').each(function () {
        var t = $(this);

        var isValid = t.data('isValid');
        if (isValid == true || isValid == false) {
            //if a parent element has a class validate-state-here 
            var specialPlace = t.closest('.validate-state-here');
            if (isValid) {
                // clear error state for all inputs that do not have errors
                t.removeClass('is-invalid').addClass('is-valid');
                specialPlace.removeClass('is-invalid').addClass('is-valid');
            }
            else {
                // set error state for all inputs that have errors
                t.addClass('is-invalid').removeClass('is-valid');
                specialPlace.addClass('is-invalid').removeClass('is-valid');

                formIsValid = false;
            }
        }
    });

    return formIsValid;
}

function validateMultiSelect(formId) {
    $('#' + formId + ' select.kendo-multiselect').each(function () {
        validateKendoMultiSelect($(this));

    });
}

function validateKendoMultiSelect(input) {

    var inputVal = input.val();
    var errorMessage = 'Please select at least one value.';
    var ms = input.data("kendoMultiSelect");
    if (ms.value().length < 1) {
        input.data('isValid', false);
        input
            .val(inputVal)
            .closest('.form-group')
            .find('.invalid-feedback')
            .html(errorMessage);
        input
            .val(inputVal)
            .closest('.form-group')
            .find('.kendo-multiselect')
            .data('isValid', false);
    }
    else {
        input
            .val(inputVal)
            .closest('.form-group')
            .find('.invalid-feedback')
            .html('');
        input
            .val(inputVal)
            .closest('.form-group')
            .find('.kendo-multiselect')
            .data('isValid', true);
    }
}

function validateKendoDate(input) {
    var value = input.val();
    var isValid = value.length != 0 && isValidDate(value);
    var errorTarget = input.closest('.k-header');
    var date = new Date();
    date.setDate(date.getDate() - 30);
    y = date.getFullYear()
    m = date.getMonth()
    d = date.getDate();
    var thirtyDaysAgo = new Date(y, m, d);
    var errorMessage = 'Please enter a valid date (mm/dd/yyyy).';

    if (isValid) {
        var endIdValidate = input.data('validateDateRangeThirtyDays');
        if (endIdValidate) {
            if (isValidDate(value)) {
                isValid = new Date(value).getTime() <= new Date(thirtyDaysAgo).getTime();
                if (!isValid) {
                    errorMessage = 'End date must be less than ' + thirtyDaysAgo.toLocaleDateString() + '.';
                }
            }
        }
    }


    if (isValid) {
        var endId = input.data('validateDateRangeEnd');
        if (endId) {
            var endValue = input.closest('form').find('#' + endId).val();
            if (isValidDate(endValue)) {
                isValid = new Date(value).getTime() <= new Date(endValue).getTime();
                if (!isValid) {
                    errorMessage = 'Start date must be less than end date.';
                }
            }
        }
    }

    if (isValid) {
        input
            .closest('.form-group')
            .find('.invalid-feedback')
            .html('');
        input
            .closest('.form-group')
            .find('.is-invalid')
            .data('isValid', true);
    }
    else {
        errorTarget.data('isValid', false);
        input
            .data('isValid', false)
            .closest('.form-group')
            .find('.invalid-feedback')
            .html(errorMessage);
    }
}

function validateDates(formId) {
    $('#' + formId + ' input.kendo-date').each(function () {
        validateKendoDate($(this));
    });
}

function isValidDate(input) {
    var dateFormat = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(input);
    if (!dateFormat)
        return false;
    var month = parseInt(dateFormat[1]);
    var day = parseInt(dateFormat[2]);
    var year = parseInt(dateFormat[3]);

    if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1)
        return false;

    var parseDate = new Date(year, month - 1, day);

    return parseDate.getFullYear() == year && parseDate.getMonth() == (month - 1) && parseDate.getDate() == day;
}
