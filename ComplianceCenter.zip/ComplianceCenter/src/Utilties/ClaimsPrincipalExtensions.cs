using BHHC.Common.Reference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Utilties
{
    public static class ClaimsPrincipalExtensions
    {
        public static string GetUserFullName(this ClaimsPrincipal claimsPrincipal)
        {
            return claimsPrincipal.FindFirstValue(BhhcClaimTypes.EmployeeBravoFullNameClaim);

        }
    }

}
