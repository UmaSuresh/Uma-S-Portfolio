using AutoMapper;
using BHHC.ComplianceCenter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Config
{
    public class Mapping:Profile
    {
        public Mapping()
        {
            CreateMap<AuditPoolSearchCriteria, AuditPool>()
                .ForMember(d => d.JurisdictionDesc, m => m.Ignore())
                .ForMember(d => d.JurisdictionID, m => m.MapFrom(cd => cd.Jurisdictions))
                .ForMember(d => d.OfficeID, m => m.MapFrom(cd => cd.Offices))
                .ForMember(d => d.Manager, m => m.MapFrom(cd => cd.Managers))
                .ForMember(d => d.ExaminerCode, m => m.MapFrom(cd => cd.Examiners))
                .ReverseMap();
        }
    }
}
