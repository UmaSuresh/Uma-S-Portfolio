using AutoMapper;
using BHHC.ComplianceCenter.Models;
using BHHC.ComplianceCenter.ServiceClients;
using BHHC.ComplianceCenter.Services;
using Common.Logging.Loggers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.ViewComponents
{
    public class CaseFolderViewComponent : ViewComponent
    {

        private readonly ISimsDWServiceClient _simsDWServiceClient;
        private readonly ISimsServiceClient _simsServiceClient;
        private readonly IMapper _mapper;

        private readonly ITransactionLogger _logger;
        private readonly IIdentityUserService _authservice;

        public CaseFolderViewComponent(ITransactionLogger logger, ISimsDWServiceClient simsDWServiceClient, IIdentityUserService authservice, ISimsServiceClient simsServiceClient, IMapper mapper)
        {
            _logger = logger;
            _simsDWServiceClient = simsDWServiceClient;
            _simsServiceClient = simsServiceClient;
            _authservice = authservice;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IViewComponentResult> InvokeAsync(AuditPool auditPool)
        {
            try
            {
                if (auditPool == null)
                {
                    return View();
                }
                var searchCriteria = _mapper.Map<AuditPool, AuditPoolSearchCriteria>(auditPool);

                var model = await _simsServiceClient.GetAuditPool(searchCriteria);
                if (model == null)
                {

                }
                return View(model);
            }
            catch (Exception ex)
            {

                throw ex;

            }



        }
    }
}
