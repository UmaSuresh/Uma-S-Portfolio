using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ComplianceCenter.Models;
using Microsoft.AspNetCore.Authorization;
using BHHC.ComplianceCenter.Services;
using Microsoft.AspNetCore.Http;
using BHHC.ComplianceCenter.ServiceClients;

namespace ComplianceCenter.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ISimsDWServiceClient _simsDWServiceClient;
        private readonly ISimsServiceClient _simsServiceClient;

        public HomeController(ISimsDWServiceClient simsDWServiceClient, ISimsServiceClient simsServiceClient)
        {
            _simsDWServiceClient = simsDWServiceClient;
            simsServiceClient= _simsServiceClient;
        }


        public   IActionResult Index()
        {
           
            return View();
        
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
