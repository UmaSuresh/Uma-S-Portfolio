using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BHHC.ComplianceCenter.Models;
using BHHC.ComplianceCenter.ServiceClients;
using BHHC.ComplianceCenter.Services;
using Common.Logging.Loggers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BHHC.ComplianceCenter.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    public class CaseFolderController : Controller
    {
        private readonly ISimsDWServiceClient _simsDWServiceClient;
        private readonly ISimsServiceClient _simsServiceClient;

        private readonly ITransactionLogger _logger;
        private readonly IIdentityUserService _authservice;
        public CaseFolderController(ITransactionLogger logger, ISimsDWServiceClient simsDWServiceClient, IIdentityUserService authservice, ISimsServiceClient simsServiceClient)
        {
            _logger = logger;
            _simsDWServiceClient = simsDWServiceClient;
            _simsServiceClient = simsServiceClient;
            _authservice = authservice;
        }



        public IActionResult AuditPool()
        {
            return View();
        }


        //[HttpPost(Name = "GetUsers")]
        //public async Task<IActionResult> GetUsers(Jurisdiction jurisdiction)
        //{
        //    try
        //    {
        //        // viewmodel.JurisdictionID = "1,25";
        //        jurisdiction.JurisdictionID = "1,25";

        //        var model = await _simsDWServiceClient.GetExaminers(jurisdiction.JurisdictionID);
        //        if (model == null)
        //        {
        //            return StatusCode(StatusCodes.Status500InternalServerError);
        //        }
        //        return Json(model);
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}

    }
}
