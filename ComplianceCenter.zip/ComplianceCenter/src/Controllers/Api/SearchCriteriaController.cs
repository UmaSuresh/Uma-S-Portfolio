using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using BHHC.ComplianceCenter.Models;
using BHHC.ComplianceCenter.ServiceClients;
using BHHC.ComplianceCenter.Services;
using Common.Logging.Loggers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BHHC.ComplianceCenter.Controllers.ApiController
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SearchCriteriaController : ControllerBase
    {
        private readonly ISimsDWServiceClient _simsDWServiceClient;
        private readonly ISimsServiceClient _simsServiceClient;
        private readonly IMapper _mapper; 

        private readonly ITransactionLogger _logger;
        private readonly IIdentityUserService _authservice;
        public SearchCriteriaController( ITransactionLogger logger, ISimsDWServiceClient simsDWServiceClient, IIdentityUserService authservice, ISimsServiceClient simsServiceClient, IMapper mapper)
        {
            _logger = logger;
            _simsDWServiceClient = simsDWServiceClient;
            _simsServiceClient = simsServiceClient;
            _authservice = authservice;
            _mapper = mapper; 
        }

        [HttpPost(Name = "GetExaminers")]
        public async Task<IActionResult> GetExaminers( AuditPool auditPool)
        {
            try
            {
                var searchCriteria = _mapper.Map<AuditPool, AuditPoolSearchCriteria>(auditPool);
                var model = await _simsServiceClient.GetUsersFilterdBySupervisors(searchCriteria);
                
                if (model == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost(Name = "GetAuditPool")]
        public async Task<IActionResult> GetAuditPool(AuditPool auditPool)
        {
            try
            {
                var searchCriteria = _mapper.Map<AuditPool, AuditPoolSearchCriteria>(auditPool);
               
                 var  model = await _simsServiceClient.GetAuditPool(searchCriteria);
            
                if (model == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        [HttpPost(Name = "GetSupervisors")]
        public async Task<IActionResult> GetSupervisors(AuditPool auditPool)
        {
            try
            {

                var searchCriteria = _mapper.Map<AuditPool, AuditPoolSearchCriteria>(auditPool);

                var model = await _simsServiceClient.GetSupervisors(searchCriteria);
                if (model == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        [HttpGet(Name = "GetAllJurisdictions")]
        public async Task<IActionResult> GetAllJurisdictions()
        {
            try
            {
                var model = await _simsServiceClient.GetAllJurisdictions();
                if (model == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"SearchCriteriaController.GetAllOffices: {ex.Message}");
                throw ex;
            }
        }

        [HttpGet(Name = "GetAllTypeOfClaims")]
        public async Task<IActionResult> GetAllTypeOfClaims()
        {
            try
            {
                var model = await _simsServiceClient.GetTypeOfClaims();
                if (model == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"SearchCriteriaController.GetAllTypeOfClaims: {ex.Message}");
                throw ex;
            }
        }

        [HttpGet(Name = "GetAllOffices")]
        public async Task<IActionResult> GetAllOffices()
        {
            try
            {
                var model = await _simsServiceClient.GetAllOffices();
                if (model == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"SearchCriteriaController.GetAllOffices: {ex.Message}");
                throw ex;
            }
        }

  
    }
}
