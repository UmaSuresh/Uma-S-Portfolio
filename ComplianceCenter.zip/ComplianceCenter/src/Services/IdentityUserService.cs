using BHHC.ComplianceCenter.Models;
using BHHC.Data.Identity.Models;
using BHHC.WebSecurity.Managers;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Services
{
    public class IdentityUserService : IIdentityUserService
    {
        private readonly BhhcUserManager _userManager;

        public IdentityUserService(BhhcUserManager userManager)
        {
            _userManager = userManager;
        }

        /// <summary>
        /// Takes a user and claims associated with them and updates the user accordingly
        /// </summary>
        public async Task<int> UpdateIdentityUserAsync(BhhcUser user, IList<ClaimHolder> userClaims)
        {
            var currentClaims = await _userManager.GetClaimsAsync(user);
            var deleteClaimsList = new List<Claim>();
            var editClaimsList = new List<Tuple<Claim, Claim>>();
            var newClaimsList = new List<IdentityUserClaim<Guid>>();

            // Prepare to modify all claims to identity user; ensure user is not modified during this step
            foreach (var claim in userClaims)
            {
                var claimExists = false;
                var newClaim = new IdentityUserClaim<Guid> { ClaimType = claim.Type, ClaimValue = claim.Value, UserId = user.Id };

                //value marked for deletion
                if (String.IsNullOrWhiteSpace(newClaim.ClaimValue))
                {
                    foreach (var oldClaim in currentClaims)
                    {
                        if (oldClaim.Type.ToLower() == newClaim.ClaimType.ToLower())
                        {
                            deleteClaimsList.Add(oldClaim);
                        }
                    }
                }
                else
                {
                    foreach (var oldClaim in currentClaims)
                    {
                        //claim is not new
                        if (oldClaim.Type.ToLower() == newClaim.ClaimType.ToLower())
                        {
                            claimExists = true;
                            //claim is an edit
                            if (oldClaim.Value.ToLower() != newClaim.ClaimValue.ToLower())
                            {
                                var tempTuple = new Tuple<Claim, Claim>(oldClaim, new Claim(oldClaim.Type, newClaim.ClaimValue, oldClaim.ValueType, oldClaim.Issuer, oldClaim.OriginalIssuer, oldClaim.Subject));
                                editClaimsList.Add(tempTuple);
                            }

                            //existing claims don't need to be handled at this time
                        }
                    }

                    //add new claim
                    if (!claimExists)
                    {
                        newClaimsList.Add(newClaim);
                    }
                }
            }

            var saveResult = new IdentityResult();
            var userManagerSuccessful = true; //assume no errors encountered

            // Remove claims marked for deletion in delete list and Save the Identity user
            if (deleteClaimsList.Count > 0)
            {
                saveResult = await _userManager.RemoveClaimsAsync(user, deleteClaimsList);
                if (!saveResult.Succeeded)
                {
                    userManagerSuccessful = false;
                }
            }

            //change all claims marked as edited and Save the Identity user
            if (editClaimsList.Count > 0)
            {
                for (int it = 0; it < editClaimsList.Count; it++)
                {
                    saveResult = await _userManager.ReplaceClaimAsync(user, editClaimsList[it].Item1, editClaimsList[it].Item2);
                    if (!saveResult.Succeeded)
                    {
                        userManagerSuccessful = false;
                    }
                }
            }

            // Save the Identity user and new claims
            for (int it = 0; it < newClaimsList.Count; it++)
            {
                user.Claims.Add(newClaimsList[it]);
            }
            saveResult = await _userManager.UpdateAsync(user);
            if (!saveResult.Succeeded)
            {
                userManagerSuccessful = false;
            }

            //error encountered in one of the update calls
            if (!userManagerSuccessful)
            {
                return 1;
            }

            //no errors encountered
            return 0;
        }
    }
}
