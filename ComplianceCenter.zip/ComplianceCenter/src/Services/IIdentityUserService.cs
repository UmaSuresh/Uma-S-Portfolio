﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BHHC.ComplianceCenter.Models;
using BHHC.Data.Identity.Models;

namespace BHHC.ComplianceCenter.Services
{
    public interface IIdentityUserService
    {
        Task<int> UpdateIdentityUserAsync(BhhcUser user, IList<ClaimHolder> userClaims);
    }
}