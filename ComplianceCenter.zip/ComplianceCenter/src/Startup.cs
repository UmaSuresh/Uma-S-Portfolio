using Autofac;
using Autofac.Extensions.DependencyInjection;
using AutoMapper;
using BHHC.Common.Resilience.Http.Clients;
using BHHC.Common.Resilience.Http.Config;
using BHHC.Common.Security;
using BHHC.Common.Security.Interfaces;
using BHHC.Common.WebSecurity;
using BHHC.ComplianceCenter.ServiceClients;
using BHHC.ComplianceCenter.Services;
using BHHC.Data.Identity.Models;
using BHHC.WebSecurity.Managers;
using BHHC.WebSecurity.Services;
using Common.Logging.Config;
using Common.Logging.Loggers;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace ComplianceCenter
{
    public class Startup
    {
        private IHostingEnvironment _hosting;

        public Startup(IConfiguration configuration, IHostingEnvironment environment)
        {
            _hosting = environment;
            var builder = new ConfigurationBuilder()
                .SetBasePath(environment.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{environment.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            Configuration = builder.Build();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            // MVC Services
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddHttpContextAccessor();
            services.AddScoped<IActionContextAccessor, ActionContextAccessor>();
            services.AddScoped<IUrlHelper>(opt =>
            {
                var actionContext = opt.GetService<IActionContextAccessor>().ActionContext;
                return new UrlHelper(actionContext);
            });

            // AutoMapper Services
            services.AddAutoMapper();

            // JWT Token Configuration
            services.Configure<JwtSecurityTokenOutboundSettings>(options => Configuration.GetSection("JwtSecurityTokenOutboundSettings").Bind(options));
            services.AddScoped<IJwtSecurityTokenManager, JwtSecurityTokenManager>();

            // Gateway Services and Configuration
            services.AddSingleton<IGatewayHttpClient, GatewayHttpClient>();
            services.Configure<GatewayClientOptions>(options => Configuration.GetSection("GatewayClientOptions").Bind(options));

            // Integrate Web Security
            var physicalProvider = _hosting.ContentRootFileProvider;
            var embeddedProvider = new EmbeddedFileProvider(Assembly.GetEntryAssembly());
            var securityProvider = new EmbeddedFileProvider(typeof(BHHC.WebSecurity.Program).GetTypeInfo().Assembly, "BHHC.WebSecurity");
            var compositeProvider = new CompositeFileProvider(physicalProvider, embeddedProvider, securityProvider);
            services.Configure<RazorViewEngineOptions>(opt => { opt.FileProviders.Add(compositeProvider); });
            services.AddSingleton<IFileProvider>(compositeProvider);

            // Identity Authorization
            services.AddIdentity<BhhcUser, BhhcRole>().AddUserManager<BhhcUserManager>().AddSignInManager<BhhcSignInManager>().AddUserStore<BhhcUserStore>().AddRoleStore<BhhcRoleStore>();
            services.AddAuthentication(IdentityConstants.ApplicationScheme);
            services.AddAuthentication(IISDefaults.AuthenticationScheme);
            // This sets the Identity authorization as the default schema to check for authorization.  It looks for the
            // authorizaton cookie vs the windows authentication checking first.
            services.AddAuthorization(options =>
            {
                var defaultAuthorizationPolicyBuilder = new AuthorizationPolicyBuilder(
                    IdentityConstants.ApplicationScheme,
                    "Identity.Application");
                defaultAuthorizationPolicyBuilder =
                    defaultAuthorizationPolicyBuilder.RequireAuthenticatedUser();
                options.DefaultPolicy = defaultAuthorizationPolicyBuilder.Build();
            });

            // This overrides Identities claim factory with a BHHC version
            services.AddScoped<IUserClaimsPrincipalFactory<BhhcUser>, BhhcUserClaimsPrincipalFactory<BhhcUser, BhhcRole>>();
            services.AddSingleton<IAuthenticationManager, AuthenticationManager>();

            services.ConfigureApplicationCookie(opt =>
            {
                opt.Cookie.Name = $"{nameof(Configuration)}.Application";
                opt.Cookie.HttpOnly = true;
                opt.Cookie.Expiration = TimeSpan.FromMinutes(240);
                int applicationExpireMinutes;
                int.TryParse(Configuration["ApplicationExpireMinutes"], out applicationExpireMinutes);
                applicationExpireMinutes = applicationExpireMinutes == 0 ? 240 : applicationExpireMinutes;  // Default to 4 hours
                opt.ExpireTimeSpan = TimeSpan.FromMinutes(applicationExpireMinutes);
                opt.SlidingExpiration = true;
                opt.LoginPath = "/Authentication/Login";
                opt.LogoutPath = "/Authentication/Logout";
                opt.AccessDeniedPath = "/error/401";
                opt.ReturnUrlParameter = "returnUrl";

                opt.Events = new CookieAuthenticationEvents
                {
                    OnRedirectToLogin = rtl =>
                    {
                        var url = rtl.Options.LoginPath.Value;
                        var loginParameters = string.IsNullOrEmpty(rtl.Request.QueryString.Value) ? "?nologin=true" : rtl.Request.QueryString.Value;

                        List<string> omits = new List<string>() { "userLogin", "secureToken", "appName" };
                        var returnUrl = string.Join('&', rtl.Request.Query.Where(q => !omits.Contains(q.Key)).Select(q => $"{q.Key}={q.Value}"));
                        var encoded = System.Net.WebUtility.UrlEncode($"?{returnUrl}");

                        rtl.Response.Redirect($"{url}{loginParameters}&returnUrl={rtl.Request.Path}{encoded}");

                        return Task.CompletedTask;
                    },
                    OnValidatePrincipal = async ovp =>
                    {
                        var userManager = ovp.HttpContext.RequestServices.GetRequiredService<UserManager<BhhcUser>>();
                        var signInManager = ovp.HttpContext.RequestServices.GetRequiredService<SignInManager<BhhcUser>>();
                        var user = await userManager.FindByNameAsync(ovp.Principal.Identity.Name);
                        var stamp = ovp.Principal.FindFirst("AspNet.Identity.SecurityStamp").Value;
                        if (stamp != user.SecurityStamp)
                        {
                            ovp.RejectPrincipal();
                            await signInManager.SignOutAsync();
                        }
                    }
                };
            });

            // Application Services
            services.AddScoped<IIdentityUserService, IdentityUserService>();
            services.AddScoped<ISimsDWServiceClient, SimsDWServiceClient>();
            services.AddScoped<ISimsServiceClient, SimsServiceClient>();
            // Start of Autofac service provider builder.
            var builder = new ContainerBuilder();
            
            builder.Populate(services);

            LoggingConfiguration.ConfigureLoggerServices(builder, services, Configuration);

            // End of Autofac implementation
            var container = builder.Build();
            return new AutofacServiceProvider(container);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment() || env.IsEnvironment("localhost"))
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
