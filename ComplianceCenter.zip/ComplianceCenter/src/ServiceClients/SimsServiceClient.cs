using AutoMapper.Configuration;
using BHHC.Common.Reference.Interfaces;
using BHHC.Common.Reference.Models;
using BHHC.Common.Resilience.Http.Clients;
using BHHC.Common.Resilience.Http.Enumerations;
using BHHC.Common.Reference.Extensions;
using BHHC.Common.Reference.Enums;
using BHHC.ComplianceCenter.Models;
using Common.Logging.Loggers;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;

namespace BHHC.ComplianceCenter.ServiceClients
{
    public class SimsServiceClient : ISimsServiceClient
    {
        private readonly IGatewayHttpClient _client;
        private readonly ITransactionLogger _logger;

        /// <summary>
        /// Constructor for SimsServiceClient
        /// </summary>
        /// <param name="client"></param>
        /// <param name="logger"></param>
        public SimsServiceClient(IGatewayHttpClient client, ITransactionLogger logger)
        {
            _client = client;
            _logger = logger;
        }

        /// <summary>
        /// Method to get 4 offices information to be populated on office dropdown
        /// </summary>
        /// <returns></returns>
        public async Task<List<Office>> GetAllOffices()
        {
            try
            {
                var offices = new List<Office>();
                var desc = await GetDatabyText("San Francisco,San Diego,Omaha,Sacramento"
                                            , "OfficeDesc", "OfficeID,OfficeDesc"
                                            , "/api/Service.Data.Sims.Generated/v1/Office?");
                offices = JsonConvert.DeserializeObject<List<Office>>(desc);
                offices.Add(new Office { OfficeID= 0, OfficeDesc= "Select All" });
                var orderedList = offices.OrderBy(o => o.OfficeID).ToList<Office>();
                return orderedList;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSServiceClient.GetAllOffices: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// Method to get types of claim to be populated on Type
        /// </summary>
        /// <returns></returns>
        public async Task<List<ClaimType>> GetTypeOfClaims()
        {   
            try
            {
                var claimTypes = new List<ClaimType>();                
                var desc = await GetDatabyText("First Aid,Indemnity,Medical Only,No Coverage,No coverage/litigated"
                                            , "ClaimantTypeDesc", "ClaimantTypeID,ClaimantTypeDesc"
                                            , "/api/Service.Data.Sims.Generated/v1/ClaimantType?");
                claimTypes = JsonConvert.DeserializeObject<List<ClaimType>>(desc);
                claimTypes.Add(new ClaimType { ClaimantTypeID = 0, ClaimantTypeDesc = "Select All" });
                var orderedList = claimTypes.OrderBy(c => c.ClaimantTypeID).ToList<ClaimType>();
                return orderedList;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSServiceClient.GetTypeOfClaims: {ex.Message}");
                throw ex;
            }
        }


        /// <summary>
        /// Method to get all active Jurisdictions
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Jurisdiction>> GetAllJurisdictions()
        {
            try
            {                
                var filters = new List<IFilterObject>
                {
                    new FilterObject{ Property = "Active", Operation = FilterOperation.Equals, Value1 = "true"}
                };
                var model = new PagedModel()
                {
                    Page = 1,
                    Size = -1,
                    Fields = "JurisdictionID, JurisdictionDesc",
                    Filter = filters.FilterJsonify()
                };
                var path = $"api/Service.Data.Sims.Generated/v1/Jurisdiction?{model.ToQueryString()}";
                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception(response.ReasonPhrase);
                }
                var data = await response.Content.ReadAsStringAsync();
                var jurisdictions = JsonConvert.DeserializeObject<List<Jurisdiction>>(data);
                jurisdictions.Add(new Jurisdiction { JurisdictionID = 0, JurisdictionDesc = "Select All" });
                var orderedList = jurisdictions.OrderBy(j => j.JurisdictionID).ToList<Jurisdiction>();
                return orderedList;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSDWServiceClient.GetAllJurisdictions: {ex.Message}");
                throw ex;
            }
        }

        

        public async Task<IEnumerable<Examiner>> GetAllExaminers (AuditPoolSearchCriteria searchCriteria)
        {
            try
            {
                var filters = new List<IFilterObject>();
                if (searchCriteria.Jurisdictions != "0")
                {
                    filters.Add(new FilterObject { Property = "JurisdictionID", Operation = FilterOperation.In, Value1 = searchCriteria.Jurisdictions });
                }
                filters.Add(new FilterObject { Property = "EntryDate", Operation = FilterOperation.Between, Value1 = searchCriteria.EntryDateFrom.ToString(), Value2 = searchCriteria.EntryDateTo.ToString() });
                PagedModel model = new PagedModel() { Page = 1, Size = -1, Filter = filters.FilterJsonify(), Fields = "ExaminerCode" };
                var path = $"/api/Service.Data.Sims.Generated/v1/Claim?{model.ToQueryString()}";
                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                var data = await response.Content.ReadAsStringAsync();
                var examiners = JsonConvert.DeserializeObject<IEnumerable<Examiner>>(data);
                var uniqueexaminers = examiners
                                  .Select(p => new { p.ExaminerCode })
                                  .Distinct()
                                  .Select(x => new Examiner { ExaminerCode = x.ExaminerCode })
                                  .OrderBy(x => x.ExaminerCode);
                return uniqueexaminers;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<IEnumerable<Users>> GetAllUsers(AuditPoolSearchCriteria searchCriteria)
        {
            try
            { 
                IEnumerable<Managers> uniqueListOfUsers = await GetUsersByOffices(searchCriteria.Offices, searchCriteria.Managers);
                var uniqueExaminers = await GetAllExaminers(searchCriteria);
                if (uniqueExaminers.Count() > 0)
                {
                    uniqueExaminers = uniqueExaminers.Append(new Examiner { ExaminerCode = "Select All", Order = 0 });
                }
                var users = uniqueExaminers.Join(uniqueListOfUsers,
                       c => c.ExaminerCode,
                       o => o.UserName,
                       (c, o) => new Users{Manager = o.Manager, ExaminerCode = c.ExaminerCode, Order = 1} );
                if (users.Count() > 0)
                {
                    users = users.Append(new Users { Manager = "Select All", Order = 0, ExaminerCode = "Select All" });
                }
                return users;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public async Task<IEnumerable<Managers>> GetSupervisors(AuditPoolSearchCriteria searchCriteria)
        {
            var returnUsers = await GetAllUsers(searchCriteria);
            return returnUsers.Select(p => new { p.Manager, p.Order }).Distinct().Select(x => new Managers { Manager = x.Manager,  Order =x.Order }).OrderBy(x => x.Order).ThenBy(t=> t.Manager);
        }



        public async Task<IEnumerable<Examiner>> GetUsersFilterdBySupervisors(AuditPoolSearchCriteria searchCriteria)
        {
           
            var returnUsers = await GetAllUsers(searchCriteria);
            return returnUsers.Select(p => new { p.ExaminerCode, p.Order }).Distinct().Select(x => new Examiner { ExaminerCode = x.ExaminerCode, Order = x.Order }).OrderBy(x => x.Order);

        }



        public async Task<IEnumerable<Managers>> GetUsersByOffices(string offices, string managers)
        {
            try
            {
                var filters = new List<IFilterObject>();
                if (offices != "0")
                {
                    filters.Add(new FilterObject { Property = "OfficeID", Operation = FilterOperation.In, Value1 = offices });
                }
                if (!string.IsNullOrWhiteSpace(managers) && managers != "Select All")
                {
                    filters.Add(new FilterObject { Property = "Manager", Operation = FilterOperation.In, Value1 = managers });
                }
                PagedModel model = new PagedModel() { Page = 1, Size = -1, Filter = filters.FilterJsonify(), Fields = "UserName,Manager" };
                var path = $"/api/Service.Data.Sims.Generated/v1/Users?{model.ToQueryString()}";
                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                var data = await response.Content.ReadAsStringAsync();
                var users = JsonConvert.DeserializeObject<IEnumerable<Managers>>(data);
                var usesrByManager = users
                                  .Select(p => new { p.Manager, p.UserName })
                                  .Distinct()
                                  .Select(x => new Managers { Manager = x.Manager, UserName = x.UserName })
                                  .OrderBy(x => x.Manager);
                return usesrByManager;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }




        /// <summary>
        /// Gets data from tables based on the comaSepartedString values using IN operator
        /// </summary>
        /// <param name="comaSeparatedString">Coma separated string that can be passed in SQL IN operation to get data</param>
        /// <param name="property">column name to apply FilterOperation.In</param>
        /// <param name="fields">column name to set the Fields property of PageModel. Output column names</param>
        /// <param name="urlWithActionName">path of the data api with action</param>
        /// <returns></returns>
        public async Task<string> GetDatabyText(string comaSeparatedString, string property, string fields, string urlWithActionName)
        {
            try
            {
                var filters = new List<IFilterObject>
                {
                    new FilterObject{
                        Property = property,
                        Operation = FilterOperation.In,
                        Value1 = comaSeparatedString
                    }
                };
                var model = new PagedModel()
                {
                    Page = 1,
                    Size = -1,
                    Fields = fields,
                    Filter = filters.FilterJsonify()
                };
                var path = urlWithActionName + $"{model.ToQueryString()}";
                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception(response.ReasonPhrase);
                }
                var data = await response.Content.ReadAsStringAsync();
                return data;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSDWServiceClient.GetDatabyText: {ex.Message}");
                throw ex;
            }
        }


        public async Task<IEnumerable<AuditPoolResults>> GetAuditPool(AuditPoolSearchCriteria searchCriteria)
        {
            try
            {
                string[] examinersList = searchCriteria.Examiners.Split(',');

                var results = new List<AuditPoolResults>();
                var filters = new List<IFilterObject>();
                IEnumerable<Users> supervisorAndCP = await GetAllUsers(searchCriteria);
                if (searchCriteria.Jurisdictions != "0")
                {
                    filters.Add(new FilterObject { Property = "JurisdictionID", Operation = FilterOperation.In, Value1 = searchCriteria.Jurisdictions });
                }
                filters.Add(new FilterObject { Property = "EntryDate", Operation = FilterOperation.Between, Value1 = searchCriteria.EntryDateFrom.ToString(), Value2 = searchCriteria.EntryDateTo.ToString() });

                var take = 40;
                var skip = 0;
                var increment = 40;
                for (int i = 0; i < examinersList.Count(); i += increment)
                {
                    string filterValue = string.Join(",", examinersList.Skip(skip).Take(take));
                    filters.Add(new FilterObject { Property = "ExaminerCode", Operation = FilterOperation.In, Value1 = filterValue });
                    var index = filters.Count() - 1;
                    PagedModel model = new PagedModel() { Page = 1, Size = -1, Filter = filters.FilterJsonify(), Fields = "ExaminerCode,ClaimNumber,LossDate,EntryDate" };
                    string query = model.ToQueryString();
                    var path = $"/api/Service.Data.Sims.Generated/v1/Claim?{query}";
                    var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                    string data = await response.Content.ReadAsStringAsync();
                    var examiners = JsonConvert.DeserializeObject<IEnumerable<AuditPoolResults>>(data);
                    results.AddRange(examiners);
                    filters.RemoveAt(index);
                    skip += increment;
                    take += increment;
                }

                var randomClaims =
                 results.GroupBy(row => row.ExaminerCode)
                     .SelectMany(g => g.OrderBy(x => Guid.NewGuid()).Take(4))
                     .ToList();

                var res = from cl in randomClaims
                          join u in supervisorAndCP
                            on cl.ExaminerCode equals u.ExaminerCode
                          where u.Order == 1
                          select new AuditPoolResults { ClaimNumber = cl.ClaimNumber, Manager = u.Manager, ExaminerCode = cl.ExaminerCode, LossDate = cl.LossDate, EntryDate = cl.EntryDate };
                
                return res.ToList<AuditPoolResults>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



    }
}
