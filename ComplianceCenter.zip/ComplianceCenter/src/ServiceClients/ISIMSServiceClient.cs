using BHHC.ComplianceCenter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.ServiceClients
{
    public interface ISimsServiceClient
    {
        Task<List<ClaimType>> GetTypeOfClaims();

        Task<List<Office>> GetAllOffices();

        Task<IEnumerable<Jurisdiction>> GetAllJurisdictions();
        Task<IEnumerable<Managers>> GetUsersByOffices(string offices, string managers);
        Task<IEnumerable<Examiner>> GetAllExaminers(AuditPoolSearchCriteria searchCriteria);
        Task<IEnumerable<Managers>> GetSupervisors(AuditPoolSearchCriteria searchCriteria);
        Task<IEnumerable<Examiner>> GetUsersFilterdBySupervisors(AuditPoolSearchCriteria searchCriteria);
        Task<IEnumerable<AuditPoolResults>> GetAuditPool(AuditPoolSearchCriteria searchCriteria);
    
    }
}
