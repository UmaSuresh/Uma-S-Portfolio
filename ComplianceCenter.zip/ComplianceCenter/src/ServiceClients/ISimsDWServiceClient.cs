using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BHHC.ComplianceCenter.Models;

namespace BHHC.ComplianceCenter.ServiceClients
{
    public interface ISimsDWServiceClient
    {
        Task<List<ClaimType>> GetTypeOfClaims();

        Task<List<Office>> GetAllOffices();
        Task<IEnumerable<Examiner>> GetExaminers(string jurisdictionID, DateTime EntryDateFrom, DateTime EntryDateTo);

    }
}
