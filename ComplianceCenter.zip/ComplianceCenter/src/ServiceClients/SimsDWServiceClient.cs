using AutoMapper.Configuration;
using BHHC.Common.Reference.Interfaces;
using BHHC.Common.Reference.Models;
using BHHC.Common.Resilience.Http.Clients;
using BHHC.Common.Resilience.Http.Enumerations;
using BHHC.Common.Reference.Extensions;
using BHHC.Common.Reference.Enums;
using BHHC.ComplianceCenter.Models;
using Common.Logging.Loggers;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.ServiceClients
{
    public class SimsDWServiceClient : ISimsDWServiceClient
    {
        private readonly IGatewayHttpClient _client;
        private readonly ITransactionLogger _logger;
        //private readonly IConfiguration _configuration;
        //private readonly IHttpContextAccessor _contextAccessor;

        public SimsDWServiceClient(IGatewayHttpClient client, ITransactionLogger logger/*, IConfiguration configuration, IHttpContextAccessor contextAccessor*/)
        {
            _client = client;
            _logger = logger;
            //_configuration = configuration;
            //_contextAccessor = contextAccessor;
        }


        public async Task<IEnumerable<Examiner>> GetExaminers(string jurisdictionID, DateTime EntryDateFrom, DateTime EntryDateTo)
        {



            try
            {
             
   
             
                var filters = new List<IFilterObject>
            {
                   new FilterObject{ Property = "JurisdictionID", Operation = FilterOperation.In, Value1 = jurisdictionID },
                   new FilterObject{ Property = "EntryDate", Operation = FilterOperation.Between, Value1 = EntryDateFrom.ToString(),Value2=EntryDateTo.ToString() }
                };

                PagedModel model = new PagedModel() { Page = 1, Size = -1, Filter = filters.FilterJsonify(), Fields = "ExaminerCode" };

                var path = $"/api/Service.Data.Sims.Generated/v1/Claim?{model.ToQueryString()}";

                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                var data = await response.Content.ReadAsStringAsync();
                var examiners = JsonConvert.DeserializeObject<IEnumerable<Examiner>>(data);


            


                  //              var uniqueexaminers =      = examiners
                  //.GroupBy(p => p.ExaminerCode)
                  //.Select(g => g.First())
                  //.ToList();


                var uniqueexaminers = examiners
                                  .Select(p => new { p.ExaminerCode})
                                  .Distinct()
                                  .Select(x => new Examiner {ExaminerCode = x.ExaminerCode })
                                  .OrderBy(x => x.ExaminerCode);
             

                return uniqueexaminers;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        /// <summary>
        /// Method to get 5 types of claims requred on dorpdown by ClaimantTypeID
        /// </summary>
        /// <returns></returns>
        public async Task<List<ClaimType>> GetTypeOfClaims()
        {
            try
            {
                var claimTypes = new List<ClaimType>();
                var claimantTypeIds = new List<int> { 1, 2, 3, 6, 8 };
                claimTypes.Add(new ClaimType { ClaimantTypeID = 0, ClaimantTypeDesc = "Select All" });
                foreach (var id in claimantTypeIds)
                {
                    var desc = await GetDataByID(id, "ClaimantTypeID", "ClaimantTypeID,ClaimantTypeDesc", "api/Service.Data.SimsDW.Generated/v1/ClaimDim?");
                    claimTypes.Add(JsonConvert.DeserializeObject<ClaimType>(desc.Trim('[', ']')));
                }
                return claimTypes;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSDWServiceClient.GetTypeOfClaims: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// This method makes a data api call and gets one type of claim at a time
        /// </summary>
        /// <param name="claimantTypeId"></param>
        /// <returns></returns>
        public async Task<string> GetClaimantTypeDescByID(int claimantTypeId)
        {
            try
            {
                var typeOfClaim = new ClaimType { ClaimantTypeID = claimantTypeId };

                var filters = new List<IFilterObject>
                {
                    new FilterObject{
                        Property = "ClaimantTypeID",
                        Operation = FilterOperation.Equals,
                        Value1 = claimantTypeId.ToString()
                    }
                };
                var model = new PagedModel()
                {
                    Page = 1,
                    Size = 1,
                    Fields = "ClaimantTypeID,ClaimantTypeDesc",
                    Filter = filters.FilterJsonify()
                };
                var path = $"api/Service.Data.SimsDW.Generated/v1/ClaimDim?{model.ToQueryString()}";
                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception(response.ReasonPhrase);
                }
                var data = await response.Content.ReadAsStringAsync();

                return data;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSDWServiceClient.GetTypeOfClaims: {ex.Message}");
                throw ex;
            }
        }

         public async Task<List<Office>> GetAllOffices()
        {
            try
            {
                var offices = new List<Office>();
                var officeIds = new List<int> { 1, 2, 20, 31 };
                offices.Add(new Office { OfficeID = 0, OfficeDesc = "Select All" });

                foreach (var office in officeIds)
                {
                    var officedesc = await GetDataByID(office, "OfficeID", "OfficeID,OfficeDesc", "api/Service.Data.SimsDW.Generated/v1/UserDim?");
                    offices.Add(JsonConvert.DeserializeObject<Office>(officedesc.Trim('[', ']')));
                }
                return offices;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSDWServiceClient.GetAllOffices: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// This Method makes a data api call and gets one record at a time
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="property">Column names that will set Property field of FilterObject</param>
        /// <param name="fields">Column names that will set Fields field of PageModel</param>
        /// <param name="apiAction">path of action name of data api</param>
        /// <returns></returns>
        public async Task<string> GetDataByID(int Id, string property, string fields, string urlWithActionName)
        {
            try
            {
                var filters = new List<IFilterObject>
                {
                    new FilterObject{
                        Property = property,
                        Operation = FilterOperation.Equals,
                        Value1 = Id.ToString()
                    }
                };
                var model = new PagedModel()
                {
                    Page = 1,
                    Size = 1,
                    Fields = fields,
                    Filter = filters.FilterJsonify()
                };
                var path = urlWithActionName+$"{model.ToQueryString()}";
                var response = await _client.GetAsync(path, AuthorizationType.AuthenticationJwt);
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception(response.ReasonPhrase);
                }
                var data = await response.Content.ReadAsStringAsync();
                return data;
            }
            catch (Exception ex)
            {
                _logger.LogError($"SIMSDWServiceClient.GetDataByID: {ex.Message}");
                throw ex;
            }
        }

        
    }
}

