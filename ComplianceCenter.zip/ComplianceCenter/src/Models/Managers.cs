using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class Managers
    {
        public string Manager { get; set; }

        public string UserName { get; set; }

        public int Order { get; set; }
    }
   
}
