using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class ClaimHolder
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
