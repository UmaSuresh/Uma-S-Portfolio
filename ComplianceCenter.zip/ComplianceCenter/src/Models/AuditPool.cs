using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class AuditPool
    {

        public string JurisdictionID { get; set; }
        public string OfficeID { get; set; }
        public string JurisdictionDesc { get; set; }
        public DateTime EntryDateTo { get; set; }
        public DateTime EntryDateFrom { get; set; }
        public string ExaminerCode { get; set; }
        public string Manager { get; set; }
        public DateTime EntryDate { get; set; }
        public DateTime LossDate { get; set; }
    }
}
