using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class AuditPoolSearchCriteria
    {
        public string Jurisdictions { get; set; }
        public string Offices { get; set; }
        public DateTime EntryDateTo { get; set; }
        public DateTime EntryDateFrom { get; set; }
        public string Managers { get; set; }
        public string Examiners { get; set; }
    }
}
