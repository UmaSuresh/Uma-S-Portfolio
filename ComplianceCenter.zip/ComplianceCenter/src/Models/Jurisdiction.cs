using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class Jurisdiction
    {

        public int JurisdictionID { get; set; }
        public string JurisdictionDesc { get; set; }


    }
}
