using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class Examiner
    {
        public string ExaminerCode { get; set; }
        public string UserKey { get; set; }
        public int Order { get; set; }
    }
}
