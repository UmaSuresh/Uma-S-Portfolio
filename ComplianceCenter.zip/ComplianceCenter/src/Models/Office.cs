using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BHHC.ComplianceCenter.Models
{
    public class Office
    {
        public int OfficeID { get; set; }

        public string OfficeDesc { get; set; }
    }
}
